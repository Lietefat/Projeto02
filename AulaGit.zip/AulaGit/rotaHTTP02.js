//Carrega o módulo HTTP e URL

var fs      = require('fs');

var http    = require('http');

var url     = require('url');



//Função para ler um arquivo e escrevê-lo na response.

function readFile(response, file){

    //Faz a leitura do arquivo de forma assíncrona

    fs.readFile(file, function(err, data){

        //Quando ler, escreve na response o conteúdo do arquivo JSON

        response.end(data);

    });

}



//Função de callback para o servidor HTTP

var callback = function(request, response){



    //define o cabeçalho (header) como o tipo de resposta

    response.writeHead(200, {"Content-type": "application/json; charset=utf-8"});



    //Faz o parse da URL separando o caminho  (rota)

    var parts   = url.parse(request.url);

    var path    = parts.path;



    //Verifica a rota

    if (parts.path == "/rota1/cadastro"){

        //Retorna o JSON do cadastro .JSON

        readFile(response, "cadastro.json");

    } else if (parts.path == "/rota1/catalogo"){

        //Retorna o JSON do catalogo .JSON

        readFile(response, "catalogo.json");

    } else if (parts.path == "/rota1/dados"){

        //Retorna o JSON dos dados .JSON

        readFile(response, "dados.json");

    } else {

        response.end ("Rota não mapeado: " + parts.path);

    }

};



// Criar um servidor HTTP que responde para todas as requisições

var server = http.createServer(callback);



// porta que o servidor vai escutar

server.listen(3000);



//mensagem ao iniciar o servidor

console.log("Servidor iniciado em http://localhost:3000/");